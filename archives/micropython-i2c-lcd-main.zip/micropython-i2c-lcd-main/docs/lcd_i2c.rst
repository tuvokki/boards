API
=======================

.. autosummary::
   :toctree: generated

LCD
---------------------------------

.. automodule:: lcd_i2c.lcd_i2c
   :members:
   :private-members:
   :show-inheritance:

HD44780 Constants
---------------------------------

.. automodule:: lcd_i2c.const
   :members:
   :private-members:
   :show-inheritance:
