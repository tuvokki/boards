MicroPython package to control HD44780 LCD displays via I2C
===========================================================

Contents
--------

.. toctree::
   :maxdepth: 1

   readme_link
   EXAMPLES
   DOCUMENTATION
   CONTRIBUTING
   lcd_i2c
   changelog_link

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
